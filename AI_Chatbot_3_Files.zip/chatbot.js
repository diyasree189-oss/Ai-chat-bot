function addMessage(text, type) {
  const chat = document.getElementById("chat");
  const message = document.createElement("div");
  message.className = "message " + type;
  message.textContent = text;
  chat.appendChild(message);
  chat.scrollTop = chat.scrollHeight;
}

function getReply(text) {
  text = text.toLowerCase();

  if (text.includes("hello") || text.includes("hi"))
    return "Hello! 👋 How can I help you?";

  if (text.includes("name"))
    return "I am an AI Chatbot created using HTML, CSS and JavaScript.";

  if (text.includes("help"))
    return "Sure! Ask me about my name, studies, or say hello.";

  if (text.includes("study"))
    return "Keep practicing regularly. 📚 You can do it!";

  if (text.includes("thank"))
    return "You're welcome! 😊";

  if (text.includes("bye"))
    return "Goodbye! 👋 Have a nice day!";

  return "Sorry, I don't understand that yet. Try another question.";
}

function sendMessage() {
  const input = document.getElementById("message");
  const text = input.value.trim();

  if (text === "") return;

  addMessage(text, "user");
  input.value = "";

  setTimeout(function() {
    addMessage(getReply(text), "bot");
  }, 400);
}

document.getElementById("message").addEventListener("keydown", function(e) {
  if (e.key === "Enter") sendMessage();
});
